/*
//Exercise 1
class Camion {
    //properties
    make: string;
    model: string;
    year: number;

    //Constructor
    constructor(make: string, model: string, year: number){
        this.make = make;
        this.model = model;
        this.year = year;
    }

    start(){
        console.log(`The ${this.make} ${this.model} (Year: ${this.year}) is starting.`);
    }
}

//Creating a Camion object
const myCamion = new Camion ("Volvo","940 B11R",2019);
const moDeuxieme = new Camion ("Mercedez","Benz",2020);

//Call the method
myCamion.start();
moDeuxieme.start();
*/
//Exercise 2
/*
First, we define a base class "Car" with properties 'make', 'model', and 'year',
 along with a "start()" method that prints a starting message.
Define a derived class "SUV" that extends 'Car'. It includes an additional property offRoadCapable
to represent whether the SUV is suitable for off-road driving.
The constructor for the "SUV" class takes parameters for 'make', 'model', 'year',
and 'offRoadCapable'. It calls the base class constructor using super() to initialize
the inherited properties.
Implement a "toggleOffRoadMode()" method in the "SUV" class that toggles the off-road capability
and prints a message accordingly.
Finally, we create an instance of the "SUV" class called 'mySUV',
call the "start()" method to start the SUV, and then toggle the off-road mode
to demonstrate the off-road capability feature.
Output:
*/
/*
class Car {
    make: string;
    model: string;
    year: number;

    constructor(make: string, model: string, year: number){
        this.make = make;
        this.model = model;
        this.year = year;
    }

    start(){
        console.log(`The ${this.make} ${this.model} (Year: ${this.year}) is starting.`);
    }
}

// Define a derived class 'SUV' that extends 'Car'
class SUV extends Car {
    // Property to represent off-road capability
    offRoadCapable: boolean;
  
    // Constructor for SUV
    constructor(make: string, model: string, year: number, offRoadCapable: boolean) {
      // Call the base class constructor
      super(make, model, year);
  
      // Initialize the off-road capability property
      this.offRoadCapable = offRoadCapable;
    }
  
    // Method to toggle off-road capability and print a message
    toggleOffRoadMode() {
      if (this.offRoadCapable) {
        console.log(`The ${this.make} ${this.model} is now in off-road mode.`);
      } else {
        console.log(`The ${this.make} ${this.model} is not suitable for off-road driving.`);
      }
    }
  }

//Creating an SUV object
const mySUV = new SUV("Toyota", "Fortuner",2023, true);
const mySUV2 = new SUV("Mercedez", "Benz",2023, false);

mySUV.start();
mySUV.toggleOffRoadMode();

mySUV2.start();
mySUV2.toggleOffRoadMode();
*/
//Exercise 3
/*
 Write a TypeScript class that defines a base class Car with properties like make,
 model, and year, along with a start() method that prints a starting message.
 Now create a class called Engine with the properties horsepower and fuelType.
 Modify the Car class to include an instance of the Engine class as a property.
 Implement a method printCarDetails()
 in the Car class that prints both car and engine details.
*/
/*
class Engine {
  horsepower: number;
  fuelType: String;

  constructor(horsepower: number, fuelType: string){
    this.horsepower = horsepower; // pren value dns seki in declarer dns class la
    this.fuelType = fuelType;
  }
}

class Car {
  make: string;
  model: string;
  year: number;
  engine: Engine;

  constructor(make:string, model:string, year:number, engine: Engine){
    this.make = make;
    this.model=model;
    this.year=year;
    this.engine = engine;
  }

  start(){
    console.log(`The ${this.make} ${this.model} (Year: ${this.year}) is starting`);
  }

  printCarDetails(){
    console.log(`Car Details: `);
    console.log(`Make: ${this.make}`);
    console.log(`Model: ${this.model}`);
    console.log(`Year: ${this.year}`);
    console.log(`Engine Details:`);
    console.log(`Horsepower: ${this.engine.horsepower}`);
    console.log(`Fuel Type: ${this.engine.fuelType}`);
  }
}

//Creating an Engine object
const myEngine = new Engine(200, "Petrol");

//Creating a car object with the engine instance
const myCar = new Car("Audi","A3",2023,myEngine);
myCar.start();
myCar.printCarDetails();
*/
