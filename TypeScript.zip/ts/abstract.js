/*
Write a TypeScript program that creates an abstract class called Shape with properties like color
and an abstract method getPerimeter().
Implement derived classes for specific shapes (e.g., Circle, Rectangle)
that extend Shape and provide concrete implementations for calculating their perimeters.
*/
/*
abstract class Shape {
    color:string;

    constructor(color:string){
        this.color = color;
    }

    abstract getPerimeter() :number;
}

class Circle extends Shape {
    radius: number;

    constructor(color:string, radius: number){
        super(color);
        this.radius = radius;
    }

    getPerimeter(): number {
        return 2 * Math.PI * this.radius;
    }
}

class Rectangle extends Shape {
    length:number;
    width:number;

    constructor(color:string, length:number, width:number){
        super(color);
        this.length = length;
        this.width = width;
    }

    getPerimeter() : number {
        return 2 * (this.length + this.width);
    }
}

const myCircle = new Circle("Black",5);
const myRec = new Rectangle ("Red", 4 , 6);


console.log(`The perimeter of the ${myCircle.color} circle is ${myCircle.getPerimeter()}`);
console.log(`The perimeter of the ${myRec.color} rectangle is ${myRec.getPerimeter()}`);
*/
//------------------------------------------------------------------------------------------------
/*
Write a TypeScript exercise that defines an abstract class called Animal with properties
like name and an abstract method makeSound().
Create derived classes (e.g., Tiger, Lion) that extend Animal and implement the makeSound() method
with the unique sound each animal makes.
*/
/*
abstract class Animal {
    name:string;

    constructor(name:string){
        this.name = name;
    }

    abstract makeSound() : string;
}

class Horse extends Animal {
    constructor(name:string){
        super(name);
    }

    makeSound(): string {
        return "HuHuHaHa";
    }
}

class Renard extends Animal {
    constructor(name:string){
        super(name);
    }

    makeSound(): string {
        return "MeowMeow";
    }
}

const cheval = new Horse ("Leszo");
const moRenard = new Renard ("Lubois");

console.log(`The cheval named ${cheval.name} makes the sound of ${cheval.makeSound()}`);
console.log(`The renard named ${moRenard.name} makes the sound of ${moRenard.makeSound()}`);

*/
//---------------------------------------------------------------------------------------------
/*
 Write a TypeScript program that defines an abstract class Employee with properties such as name,
 employeeId, and an abstract method calculateSalary().
 Create derived classes (e.g., FullTimeEmployee, PartTimeEmployee)
 that extend Employee and provide salary calculation logic based on employment type.
*/
/*
abstract class Employee {
    name: string;
    employeeId: string;

    constructor(name:string, employeeId: string){
        this.name = name;
        this.employeeId = employeeId;
    }

    abstract calculateSalary() : number;
}

class FullTimeEmployee extends Employee {
    monthlySalary : number;

    constructor(name:string, employeeId: string, monthlySalary: number){
        super(name, employeeId);
        this.monthlySalary = monthlySalary;
    }

    calculateSalary(): number {
        return this.monthlySalary;
    }
}

class PartTimeEmployee extends Employee {
    hourlyRate : number;
    hoursWorked : number;

    constructor(name:string, employeeId:string, hourlyRate: number, hoursWorked: number){
        super(name, employeeId);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    calculateSalary(): number {
        return (this.hourlyRate * this.hoursWorked);
    }
}

const fullTimeEmployee = new FullTimeEmployee("James Potter", "123456",40000);
const partTimeEmployee = new PartTimeEmployee ("Dobby is not a free elf","MalfoySoMacro",1,5);

console.log(`Full-Time Employee ${fullTimeEmployee.name}'s employeeid ${fullTimeEmployee.employeeId} Salary: $${fullTimeEmployee.calculateSalary()}`);
console.log(`Part-Time Employee ${partTimeEmployee.name}'s employeeid ${partTimeEmployee.employeeId} Salary: $${partTimeEmployee.calculateSalary()}`);
*/
//---------------------------------------------------------------------------------------------
/*
Write a TypeScript program that creates an abstract class GeometricShape
with properties like name and abstract methods for calculating area and perimeter.
Implement derived classes for specific shapes (e.g., Circle, Rectangle, Triangle)
that extend GeometricShape and provide concrete implementations for area and perimeter calculations.
*/
/*
abstract class GeometricShape {
    name:string;
    constructor(name:string){
        this.name =name;
    }

    abstract area(): number;
    abstract perimeter() : number;
}

class Circle extends GeometricShape {
    name: string;
    radius: number;

    constructor(name:string,radius: number){
        super(name);
        this.radius =radius;
    }

    area(): number{
        return Math.PI * this.radius **2;
    }

    perimeter() : number{
        return 2 * Math.PI * this.radius;
    }
}

class Rectangle extends GeometricShape {
    name:string;
    length:number;
    width:number;

    constructor(name:string, length:number, width: number){
        super(name);
        this.length = length;
        this.width = width;
    }

    area(): number {
        return (this.width * this.length);
    }

    perimeter(): number{
        return 2*(this.length + this.width);
    }
}

class Triangle extends GeometricShape{
    name:string;
    base: number;
    height: number;

    constructor(name:string, base:number, height:number){
        super(name);
        this.base = base;
        this.height = height;
    }

    area() : number {
        return (0.5 * this.base * this.height);
    }

    perimeter(): number {
        return 3*this.base;
    }
}

const circle = new Circle("Circle",5);
const rectangle = new Rectangle("Rec", 4, 6);
const triangle = new Triangle("Tri",3,4);

console.log(`${circle.name} - Area: ${circle.area()}, Perimeter: ${circle.perimeter()}`);
console.log(`${rectangle.name} - Area: ${rectangle.area()}, Perimeter: ${rectangle.perimeter()}`);
console.log(`${triangle.name} - Area: ${triangle.area()}, Perimeter: ${triangle.perimeter()}`);
*/ 
