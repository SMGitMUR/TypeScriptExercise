/*
Write a TypeScript class called Student with the following properties and methods:

private name: string
protected studentId: number
The class should have a constructor that accepts a name and student ID. Implement a method:

public displayInfo(): void that displays the student's name and ID.

Make sure that the studentId property is accessible only within the class and its subclasses.
 */
/*
class Student {
    private name:string;
    protected studentId: number;

    constructor(name:string, studentId: number){
        this.name = name;
        this.studentId = studentId;
    }

    public displayInfo(): void {
        console.log(`Student Name: ${this.name}, student ID: ${this.studentId}`);
    }
}

const student = new Student("Pascaline Lubois", 12);
student.displayInfo();

*/
//---------------------------------------------------------------------------------------------
/*
Write a TypeScript class called BankAccount with the following properties and methods:
private accountNumber: string
protected balance: number
The class should have a constructor that accepts an account number and initializes the balance to 0. 
It should also include methods:
public deposit(amount: number): void to add funds to the account.
public withdraw(amount: number): void to deduct funds from the account.
Only the class and its subclasses should have access to the balance property.
 */
/*
class BankAccount {
    private accountNumber : string;
    protected balance : number;

    constructor(accountNumber: string){

        this.accountNumber = accountNumber;
        this.balance = 0;
    }

    public deposit(amount : number) : void {
        if(amount > 0) {
            this.balance += amount;
            console.log(`Deposited $ ${amount}. New balance:$ ${this.balance}`);
        } else {
            console.log("Invalide deposit amount.");
        }
    }

    public withdraw(amount : number) : void {
        if(amount > 0 && amount <= this.balance){
            this.balance -= amount;
            console.log(`Withdrawn $ ${amount}. New balance: $ ${this.balance}`);
        } else {
            console.log("Invalide withdrawal amount or insufficient balance");
        }
    }
}

const bankAccount = new BankAccount ("12345");
bankAccount.deposit(1200);
bankAccount.withdraw(400);
bankAccount.withdraw(1000);
*/
//---------------------------------------------------------------------------------------------
/*
Write a TypeScript program that creates a class called Car with the following properties and methods:
protected make: string
protected model: string
The class should have a constructor that accepts make and model. Implement a method:
public getCarInfo(): string that returns a string containing the make and model of the car.
Make sure that the make and model properties are only accessible within the class and its subclasses.
*/
/*
class Voiture {
    protected make: string;
    protected model: string;

    constructor(make:string, model:string){
        this.make = make;
        this.model = model;
    }

    public getCarInfo() : string {
        return (`I own a ${this.make} ${this.model}`);
    }
}

const moLoto = new Voiture ("Honda","Civic");
console.log(moLoto.getCarInfo());

const moLoto2 = new Voiture ("Mercedes","Benz");
console.log(moLoto2.getCarInfo());
*/
//---------------------------------------------------------------------------------------------
/*
Write a TypeScript program that creates a class called Animal with the following properties and methods:
protected name: string
private age: number
The class should have a constructor that accepts name and age. Implement a method:
public introduce(): string that returns a string introducing the animal, including its name and age.
Ensure that the age property is accessible only within the class.
*/
/*
class Animal {
    protected name:string;
    private age: number;

    constructor(name:string, age: number){
        this.name =name;
        this.age = age;
    }

    public introduce() : string {
       return(`Hi, I'm ${this.name}, and I am ${this.age} years old.`);
    }
}

const ani = new Animal ("Blacky",5);
console.log(ani.introduce());
*/
//---------------------------------------------------------------------------------------------
/*
Write a TypeScript class called Counter with a static property count initialized to 0. 
Implement a static method increment() that increments the count by 1. 
Implement another static method getCount() that returns the current count value. 
Test the class by calling both methods.
*/
/*
class Counter {
    private static count : number = 0;

    static increment() : void {
        Counter.count ++;
    }

    static getCount(): number {
        return Counter.count;
    }
}

Counter.increment();
Counter.increment();
Counter.increment();
Counter.increment();

console.log(`Current count: ${Counter.getCount()}`);
*/
//---------------------------------------------------------------------------------------------
/*
Write a TypeScript program that creates a class with static methods for common mathematical operations,
 such as add, subtract, multiply, and divide. 
 Each method should accept two numbers as parameters and return the operation result. 
 Test the class by performing various mathematical operations using its static methods.
*/

class Maths {
    static add(x: number, y: number): number {
      return x + y;
    }
  
    static subtract(x: number, y: number): number {
      return x - y;
    }
  
    static multiply(x: number, y: number): number {
      return x * y;
    }
  
    static divide(x: number, y: number): number {
      if (y === 0) {
        throw new Error("Division by zero is not allowed.");
      }
      return x / y;
    }
  }
  
  // Testing the Maths class
  const num1 = 12;
  const num2 = 5;
  
  console.log(`Addition: ${Maths.add(num1, num2)}`); // Output: Addition: 17
  console.log(`Subtraction: ${Maths.subtract(num1, num2)}`); // Output: Subtraction: 7
  console.log(`Multiplication: ${Maths.multiply(num1, num2)}`); // Output: Multiplication: 60
  console.log(`Division: ${Maths.divide(num1, num2)}`); // Output: Division: 2.4