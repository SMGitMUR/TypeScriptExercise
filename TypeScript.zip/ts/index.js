//Exercise 1
var emp_name = "Sarvesh Madhoo";
var lage = 25;
console.log("Name:", emp_name);
console.log("Age:", lage);
//Exercise 2
var n1 = 42;
var strVariable = "Hello, TypeScript";
var boolVariable = true;
var undefinedVariable = undefined;
var n2 = 10;
var sum = n1 + n2;
console.log("Sum:", sum);
var concatenatedString = strVariable + " How are you ?";
console.log("Concatenated String:", concatenatedString);
var isTrue = boolVariable && true;
console.log("Logical AND:", isTrue);
if (undefinedVariable === undefined) {
    console.log("undefined");
}
else {
    console.log("Not undefined");
}
// Exercise 3
var str_num = "100";
var numberFromAssertion = parseInt(str_num);
console.log("Number from assertion: ", numberFromAssertion);
var numberValue = 200;
var stringFromAssertion = numberValue.toString();
console.log("String from assertion: ", stringFromAssertion);
var student1 = {
    id: 1,
    studentName: "James Potter",
    email: "jamespotter@gmail.com",
};
var student2 = {
    id: 2,
    studentName: "Harry Potter",
    email: "HarryPotter@gmail.com"
};
var originPoint = {
    x: 0,
    y: 0,
};
function printStudentInfo(student) {
    console.log("Student ID: ".concat(student.id));
    console.log("Studentname: ".concat(student.studentName));
    console.log("Email: ".concat(student.email));
}
function calculateDistance(point1, point2) {
    var dx = point1.x - point2.x;
    var dy = point1.y - point2.y;
    return Math.sqrt(dx * dx + dy * dy);
}
console.log("Student 1 : ");
printStudentInfo(student1);
console.log("\nStudent 2: ");
printStudentInfo(student2);
console.log("\nDistance from origin: ");
console.log(calculateDistance(originPoint, { x: 3, y: 4 }));
//Exercise 4
var colors = ["Red", "Green", "Blue", "Orange"];
//inserting elements
colors.push("White");
colors.push("Pink");
//Removing element in array
colors.pop();
//using a loop to display all colors
console.log("Array Elements");
for (var _i = 0, colors_1 = colors; _i < colors_1.length; _i++) {
    var c = colors_1[_i];
    console.log(c);
}
var searchColor = "Green";
var isColorInArray = colors.includes(searchColor);
console.log("Is ".concat(searchColor, " in the array? ").concat(isColorInArray ? "Yes" : "No"));
//Finding index
var indexOfBlue = colors.indexOf("Blue");
console.log("Index of \"Blue\" in the array: ".concat(indexOfBlue));
if (indexOfBlue !== -1) {
    colors.splice(indexOfBlue, 1);
}
console.log("Modified Array: ");
console.log(colors);
//Exercise 5
var Color;
(function (Color) {
    Color[Color["Red"] = 0] = "Red";
    Color[Color["Green"] = 1] = "Green";
    Color[Color["White"] = 2] = "White";
    Color[Color["Blue"] = 3] = "Blue";
})(Color || (Color = {}));
console.log("List of colors:", Color);
var selectedColor = Color.Green;
console.log("Selected Color:", selectedColor);
//Exercise 6
var result;
function logType(arg) {
    if (typeof arg === "string") {
        console.log("Type: string", result);
    }
    else if (typeof arg === "number") {
        console.log("Type: number", result);
    }
    else if (typeof arg === "boolean") {
        console.log("Type: boolean", result);
    }
    else {
        console.log("Type: unknown", result);
    }
}
result = "TypeScript";
logType(result);
result = 100;
logType(result);
result = true;
logType(result);
//Exercise 7
function combine(param1, param2) {
    if (param1) {
        return param2 * 3;
    }
    else {
        return !param1;
    }
}
var result1 = combine(true, 24);
var result2 = combine(false, -20);
console.log("Result-1", result1);
console.log("Result-2:", result2);
var car = { make: "Audi", model: "A4" };
var bus = { make: "Volvo", model: "XC60", payloadCapacity: 20 };
var vehicles = [car, bus];
vehicles.forEach(function (vehicle) {
    console.log("Make: ".concat(vehicle.make));
    console.log("Model: ".concat(vehicle.model));
    if ("payloadCapacity" in vehicle) {
        console.log("Payload Capacity: ".concat(vehicle.payloadCapacity));
    }
    console.log("----------------");
});
//exercise 9
function printElement(element) {
    if (typeof element === "string") {
        console.log("Element is a string:", element);
    }
    else if (typeof element === "number") {
        console.log("Element is a number:", element);
    }
    else {
        console.log("Element is neither a string nor a number");
    }
}
printElement("TypeScript");
printElement(200);
printElement(-40.6);
//exercise 10
function isOdd(num) {
    if (typeof num === "number" && isFinite(num)) {
        return num % 2 !== 0;
    }
    else {
        return false;
    }
}
console.log("Is 7 an odd", isOdd(7));
console.log("Is 20 an odd", isOdd(20));
console.log("Is -5 an odd", isOdd(-5));
//exercise 11
var mixedData = [-12, "one", 10, false, "two", 34, true, "three"];
console.log("Original array elements: ", mixedData);
var numbersOnly = mixedData.filter(function (item) { return typeof item === "number"; });
console.log("Numbers Only: ", numbersOnly);
var booleanOnly = mixedData.filter(function (item) { return typeof item === "boolean"; });
console.log("Boolean only: ", booleanOnly);
var stringOnly = mixedData.filter(function (item) { return typeof item === "string"; });
console.log("String only: ", stringOnly);
//exercise 12
var anyValue = "This is type 'any'";
var stringValue = anyValue;
console.log("stringValue: ", stringValue);
console.log("Type of stringValue: ", typeof stringValue);
//exercise 13
function calculateLength(input) {
    var strings = (typeof input === "string" ? [input] : input);
    var totalLength = strings.reduce(function (length, str) { return length + str.length; }, 0);
    return totalLength;
}
var singleString = "Hello, TypeScript";
var stringArray = ["Coding", "TypeScript", "Exercise"];
var length1 = calculateLength(singleString);
var length2 = calculateLength(stringArray);
console.log("Length 1: " + length1);
console.log("Length 2: " + length2);
