
/*
//Exercise 1
let emp_name: string = "Sarvesh Madhoo";
let lage: number = 25;

console.log("Name:", emp_name);
console.log("Age:", lage);

//Exercise 2
let n1: number =42;
let strVariable: string = "Hello, TypeScript";
let boolVariable: boolean = true;
let undefinedVariable: undefined = undefined;

const n2: number =10;

const sum: number = n1 + n2;
console.log("Sum:", sum);

const concatenatedString: string = strVariable + " How are you ?";
console.log("Concatenated String:", concatenatedString);

const isTrue: boolean = boolVariable && true;
console.log("Logical AND:", isTrue);

if(undefinedVariable === undefined){
   console.log("undefined");
} else {
   console.log("Not undefined");
}
// Exercise 3
let str_num: string ="100";
let numberFromAssertion: number = parseInt(str_num);
console.log("Number from assertion: ", numberFromAssertion);


let numberValue: number =200;
let stringFromAssertion: string = numberValue.toString();
console.log("String from assertion: ", stringFromAssertion);

//exercise 4
type Student = {
   id: number;
   studentName: string;
   email: string;
};

type Point = {
   x: number;
   y: number;
}

const student1: Student = {
   id:1,
   studentName: "James Potter",
   email:"jamespotter@gmail.com",
};

const student2: Student = {
   id:2,
   studentName: "Harry Potter",
   email:"HarryPotter@gmail.com"
}

const originPoint : Point = {
   x:0,
   y:0,
};

function printStudentInfo(student: Student){
   console.log(`Student ID: ${student.id}`);
   console.log(`Studentname: ${student.studentName}`);
   console.log(`Email: ${student.email}`);
}

function calculateDistance(point1: Point, point2: Point) : number {
   const dx = point1.x - point2.x;
   const dy = point1.y - point2.y;
   return Math.sqrt(dx * dx + dy * dy);
}

console.log("Student 1 : ");
printStudentInfo(student1);

console.log("\nStudent 2: ");
printStudentInfo(student2);


console.log("\nDistance from origin: ");
console.log(calculateDistance(originPoint,{x:3, y:4}));


//Exercise 4
const colors: string[] =["Red","Green","Blue","Orange"];

//inserting elements
colors.push("White");
colors.push("Pink");

//Removing element in array
colors.pop();

//using a loop to display all colors
console.log("Array Elements");
for(const c of colors){
   console.log(c);
}

const searchColor ="Green";
const isColorInArray = colors.includes(searchColor);
console.log(`Is ${searchColor} in the array? ${isColorInArray ? "Yes" : "No"}`);

//Finding index
const indexOfBlue = colors.indexOf("Blue");
console.log(`Index of "Blue" in the array: ${indexOfBlue}`);

if(indexOfBlue !==-1){
   colors.splice(indexOfBlue,1);
}

console.log("Modified Array: ");
console.log(colors);

//Exercise 5

enum Color {
   Red,
   Green,
   White,
   Blue,
}

console.log("List of colors:", Color);

let selectedColor: Color = Color.Green;

console.log("Selected Color:", selectedColor);


//Exercise 6

let result : string | number | boolean;

function logType(arg: string | number| boolean) : void {
   if (typeof arg === "string"){
      console.log("Type: string",result);
   }else if (typeof arg === "number"){
      console.log("Type: number", result);
   } else if (typeof arg === "boolean"){
      console.log("Type: boolean",result);
   } else {
      console.log("Type: unknown",result);
   }
} 

result = "TypeScript";
logType(result);

result = 100;
logType(result);

result = true;
logType(result);

//Exercise 7

function combine (param1: boolean, param2: number): boolean | number {
   if (param1) {
      return param2*3;
   } else {
      return !param1;
   }
}

const result1: boolean | number = combine(true,24);
const result2: boolean | number = combine(false,-20);

console.log("Result-1", result1);
console.log("Result-2:", result2);


//Exercise 8

interface Car {
   make: string;
   model: string;
}

type Bus = {
   make: string;
   model: string;
   payloadCapacity: number;
};

type Vehicle = Car | Bus;

const car: Car = {make: "Audi",model:"A4"};
const bus: Bus = {make:"Volvo", model:"XC60",payloadCapacity:20};

const vehicles: Vehicle[] = [car,bus];

vehicles.forEach((vehicle)=>{
   console.log(`Make: ${vehicle.make}`);
   console.log(`Model: ${vehicle.model}`);
   if("payloadCapacity" in vehicle){
      console.log(`Payload Capacity: ${vehicle.payloadCapacity}`);
   } 
   console.log("----------------");

});

//exercise 9
function printElement(element: string | number): void {
   if(typeof element === "string"){
      console.log("Element is a string:", element);
   }
   else if (typeof element ==="number"){
      console.log("Element is a number:", element);
   }
   else {
      console.log("Element is neither a string nor a number");
   }
}

printElement("TypeScript");
printElement(200);
printElement(-40.6);


//exercise 10
function isOdd(num: number): boolean {
   if(typeof num === "number" && isFinite(num)){
      return num % 2 !==0;
   }else{
      return false;
   }
}

console.log("Is 7 an odd",isOdd(7));
console.log("Is 20 an odd",isOdd(20));
console.log("Is -5 an odd",isOdd(-5));



//exercise 11

const mixedData: (number | string | boolean ) [] = [-12,"one",10,false,"two",34,true,"three"];
console.log("Original array elements: ", mixedData);

const numbersOnly: number[] = mixedData.filter((item): item is number => typeof item === "number");
console.log("Numbers Only: ", numbersOnly);

const booleanOnly: boolean[] = mixedData.filter((item): item is boolean => typeof item ==="boolean");
console.log("Boolean only: ",booleanOnly);

const stringOnly : string[] = mixedData.filter((item): item is string => typeof item === "string");
console.log("String only: ", stringOnly);

//exercise 12

let anyValue: any = "This is type 'any'";

let stringValue: string = anyValue as string;

console.log("stringValue: ", stringValue);
console.log("Type of stringValue: ", typeof stringValue);

//exercise 13

function calculateLength(input: string | string[]) : number {
   const strings : string [] = (typeof input === "string" ? [input]: input) as string [];
   const totalLength = strings.reduce((length, str) => length + str.length,0);
   return totalLength;
}

const singleString = "Hello, TypeScript";
const stringArray = ["Coding", "TypeScript","Exercise"];
const length1 = calculateLength(singleString);
const length2 = calculateLength(stringArray);

console.log("Length 1: "+ length1);
console.log("Length 2: "+ length2);

*/