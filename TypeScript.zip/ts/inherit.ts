/*
 Write a TypeScript class called Animal with properties name and species. 
 Implement a constructor that initializes these properties when an Animal object is created. 
 Next, create a derived class Tiger that extends Animal. 
 Add a method roar() to the Tiger class that prints a message indicating that the tiger is roaring.  
 */

//---------------------------------------------------------------------------------------
/*
 class Animal {
    name: string;
    species:string;

    constructor(nom:string, especes?:string){
        this.name = nom;
        this.species = especes;
    }
 }

 class Tiger extends Animal {
    roar (){
        console.log(`The tiger named ${this.name} is roaring`);
    }
 }

 const monTigre = new Tiger ("Lubois");
 monTigre.roar();
 */
// ----------------------------------------------------------------------------------------

/*
Write a TypeScript class called Person with properties name and age. 
Implement a constructor that initializes these properties when a Person object is created. 
Then, create a derived class Employee that extends Person. 
Override the constructor of the Employee class to include an additional property employeeId.
*/

//-------------------------------------------------------------------------------------------
/*
// Define the base class 'Person'
class Person {
    // Properties
    name: string;
    age: number;
  
    // Constructor for Person
    constructor(name: string, age: number) {
      this.name = name;
      this.age = age;
    }
  }
  
  // Define the derived class 'Employee' extending 'Person'
  class Employee extends Person {
    // Additional property for Employee
    employeeId: string;
  
    // Constructor for Employee (override)
    constructor(name: string, age: number, employeeId: string) {
      // Call the constructor of the base class 'Person'
      super(name, age);
  
      // Initialize the 'employeeId' property
      this.employeeId = employeeId;
    }
  }
  // Create an Employee object
  const myEmployee = new Employee ("Christelle Pascaline lubois",40,"pasLeboisMaisLubois");

  // Access and print the properties
  console.log("Name: ",myEmployee.name);
  console.log("Age: ", myEmployee.age);
  console.log("Employee ID: ", myEmployee.employeeId);

  // Create an Employee object
  const myEmployee2 = new Employee ("James Potter",45,"EPM-0012");

  // Access and print the properties
  console.log("Name: ",myEmployee2.name);
  console.log("Age: ", myEmployee2.age);
  console.log("Employee ID: ", myEmployee2.employeeId);
*/
//-------------------------------------------------------------------------------------------

/**
 Write a TypeScript program that creates a class called Shape with properties color and a method draw(). 
 This program prints a message indicating that the shape is being drawn. 
 Then, create a derived class Circle that extends Shape. 
 Override the draw() method in the Circle class to provide a specific implementation for drawing a circle.  
 */
/*
 class Shape {
    color:string;

    constructor(color:string){
        this.color = color;
    }

    draw(){
        console.log(`The shape is being drawn`);
    }
 }

 class Circle extends Shape {
    constructor(color){
        super(color);
    }

    draw(){
        console.log(`Drawing a ${this.color} circle`);
    }
 }

 const myCircle = new Circle ("Green");

 myCircle.draw();
 */
//-------------------------------------------------------------------------------------------
/*
Write a TypeScript program that defines a class called Vehicle with properties make and model. 
Implement a constructor that initializes these properties when a Vehicle object is created. 
Then, create a derived class Car that extends Vehicle. 
Finally, create a derived class SportsCar that extends Car. 
Ensure that properties are inherited correctly and each class has its own constructor. 
*/
//-------------------------------------------------------------------------------------------

class Vehicle {
    make:string;
    model:string;

    constructor(make:string, model:string){
        this.make = make;
        this.model = model;
    }
}

class Car extends Vehicle {
    constructor(make: string,model: string){
        super(make,model);
    }
}

class sportCar extends Vehicle {
    constructor(make:string, model:string){
        super(make,model);
    }
}

const mySportCar = new sportCar ("Toyota","Prius");

console.log("Make: ", mySportCar.make);
console.log("Model: ", mySportCar.model);