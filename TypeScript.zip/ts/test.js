//Constructors
//exercise 5
/*
Write a TypeScript program that creates a class called Student with properties name and class.
Implement a constructor that initializes these properties when a Student object is created.
class Zeleve {
    name:string;
    class:string;
    colege:string;

    constructor(name:string, clas:string, colege:string){
        this.name = name;
        this.class = clas;
        this.colege = colege;
    }

    isStudent(){
        console.log (`${this.name} is a student of the class ${this.class} of the colege ${this.colege}`);
    }
}

const myStudent = new Zeleve ("Deku","Class1A","YEHUEI");
myStudent.isStudent();


const myStudent2 = new Zeleve ("Gojo","Sorcerer","JijutsiKaisen");
myStudent2.isStudent();
*/
/*
//Exercise 6
class Student{
    name:string;
    class:string | undefined;
    rollnumber: number | undefined;

 
  constructor(name: string, clas?:string, rollNumber?: number) {
    this.name = name;
    this.class = clas;
    this.rollnumber = rollNumber;
  }

}

// Create Student objects using different constructors
const studentWithRollNumber = new Student("James Potter","",12);
const studentWithoutRollNumber = new Student("Ben Ten","Class 1A");

// Access and print the properties
console.log("Student with Roll Number:");
console.log("Name:", studentWithRollNumber.name);
console.log("Class:", studentWithRollNumber.class);
console.log("Roll Number:", studentWithRollNumber.rollnumber);

console.log("\nStudent without Roll Number:");
console.log("Name:", studentWithoutRollNumber.name);
console.log("Class:", studentWithoutRollNumber.class);
console.log("Roll Number:", studentWithoutRollNumber.rollnumber);
*/
/*
Write a TypeScript class called Shape with properties like color.
Implement a constructor that initializes the color property when a Shape object is created.
Then, create a derived class Circle that extends Shape.
Implement a constructor for the Circle class that takes color and radius
as parameters and initializes them along with the color property of the base class.
*/
/*
class Shape{
    color:string;

    constructor(color:string)
    {
        this.color = color;
    }
}

class Circle extends Shape{
    radius: number

    constructor(color: string, radius: number){
        super(color);
        this.radius=radius;
    }
}

const myCircle = new Circle("Black", 7);
console.log("Color: ", myCircle.color);
console.log("Radius: ", myCircle.radius);
*/
/*
Write a TypeScript class called Student with properties name and age.
Implement a constructor that initializes these properties when a Student object is created.
Additionally, add validation to ensure that the age provided is a positive number.
If the age is not positive, set it to a default value of 0.
*/
/*
class Student {
    name:string;
    age: number;

    constructor(nom:string, lage: number){
        this.name = nom;

        if(lage > 0){
            this.age =lage;
        } else {
            this.age =0;
        }
        
    }
}

const moZeleve = new Student ("ram", 4);
const moZeleve2 = new Student ("nagi", 26);
const moZeleve3 = new Student ("james", -26);

console.log("Student 1 - Name:", moZeleve.name, "Age:", moZeleve.age);
console.log("Student 2 - Name:", moZeleve2.name, "Age:", moZeleve2.age);
console.log("Student 2 - Name:", moZeleve3.name, "Age:", moZeleve3.age);
*/ 
