//Implicit Types
let helloWord = "Hello, World";

//Explicit types
let firstName: string = 'John';
let age: number = 30;

/* Variables types
Built in Types
Boolean
Number
String
Array
Tuple
Enum
Unknown
Any
Void
Null and Undefined
*/

//Tuple using array
type stringAndNumber = [string, number];
let x: stringAndNumber = ["Hello", 10];

//Enums
 enum Continents {
    North_America,
    South_America,
    Africa,
    Asia,
    Europe,
    Antartica,
    Australia
 }

 var region = Continents.Africa;

 //Interface
 interface User {
    name: string;
    id: number;
 }

 const user: User = {
    name: 'John',
    id:0
}

const getLength = (param: string | any[]) => {
    return param.length;
}

getLength('test');
getLength(['test','test1']);
